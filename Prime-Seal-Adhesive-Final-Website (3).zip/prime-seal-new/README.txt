PRIME SEAL ADHESIVE WEBSITE

Preview: Open index.html in a modern browser.

GitHub Pages publishing:
1. Create a PUBLIC GitHub repository (example: prime-seal-website).
2. Upload the contents of this folder to the repository root. Keep index.html at root and include the assets folder.
3. Open Settings > Pages.
4. Under Build and deployment choose Deploy from a branch, select main and /(root), then Save.
5. After deployment, your site will be available at https://YOUR-USERNAME.github.io/REPOSITORY-NAME/.

Contact details on site:
WhatsApp: +91 99130 70059
Email: primesealadhesive@gmail.com
Location: Godhra, Panchmahal, Gujarat, India

Note: ASTM details were provided by the business owner. Please verify product test reports and applicable claims before publication. ISO certification and USA-origin formulation are not asserted without supporting details.
